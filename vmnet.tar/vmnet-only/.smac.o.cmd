savedcmd_smac.o := gcc -Wp,-MMD,./.smac.o.d -nostdinc -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated/uapi -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/generated/uapi -include /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler-version.h -include /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kconfig.h -include /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler_types.h -D__KERNEL__ -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -fcf-protection=branch -fno-jump-tables -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -march=x86-64 -mtune=generic -mno-red-zone -mcmodel=kernel -mstack-protector-guard-reg=gs -mstack-protector-guard-symbol=__ref_stack_chk_guard -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -ftrivial-auto-var-init=zero -fzero-init-padding-bits=all -fno-stack-clash-protection -pg -mrecord-mcount -mfentry -DCC_USING_FENTRY -fno-inline-functions-called-once -fmin-function-alignment=16 -fstrict-flex-arrays=3 -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-main -Wno-dangling-pointer -Wvla -Wno-pointer-sign -Wcast-function-type -Wno-unterminated-string-initialization -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-type-limits -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -g  -fsanitize=bounds-strict -fsanitize=shift    -DMODULE  -DKBUILD_BASENAME='"smac"' -DKBUILD_MODNAME='"vmnet"' -D__KBUILD_MODNAME=kmod_vmnet -c -o smac.o smac.c  

source_smac.o := smac.c

deps_smac.o := \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_INTEGER_WRAP) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler_attributes.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler-gcc.h \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  smac_compat.h \
  vm_basic_types.h \
  includeCheck.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated/uapi/asm/types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/int-ll64.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/int-ll64.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi/asm/bitsperlong.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitsperlong.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/bitsperlong.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/posix_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/stddef.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/stddef.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi/asm/posix_types_64.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/posix_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/generated/uapi/linux/version.h \
  smac.h \
  vm_basic_defs.h \
  vm_basic_asm.h \
  vm_basic_asm_x86_common.h \
  vm_basic_asm_x86_64.h \

smac.o: $(deps_smac.o)

$(deps_smac.o):
