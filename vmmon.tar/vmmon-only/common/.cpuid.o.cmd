savedcmd_common/cpuid.o := gcc -Wp,-MMD,common/.cpuid.o.d -nostdinc -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated/uapi -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi -I/usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/generated/uapi -include /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler-version.h -include /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kconfig.h -include /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler_types.h -D__KERNEL__ -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mno-sse -mno-mmx -mno-sse2 -mno-3dnow -mno-avx -fcf-protection=branch -fno-jump-tables -m64 -falign-jumps=1 -falign-loops=1 -mno-80387 -mno-fp-ret-in-387 -mpreferred-stack-boundary=3 -mskip-rax-setup -march=x86-64 -mtune=generic -mno-red-zone -mcmodel=kernel -mstack-protector-guard-reg=gs -mstack-protector-guard-symbol=__ref_stack_chk_guard -Wno-sign-compare -fno-asynchronous-unwind-tables -mindirect-branch=thunk-extern -mindirect-branch-register -mindirect-branch-cs-prefix -mfunction-return=thunk-extern -fno-jump-tables -mharden-sls=all -fpatchable-function-entry=16,16 -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -ftrivial-auto-var-init=zero -fzero-init-padding-bits=all -fno-stack-clash-protection -pg -mrecord-mcount -mfentry -DCC_USING_FENTRY -fno-inline-functions-called-once -fmin-function-alignment=16 -fstrict-flex-arrays=3 -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-main -Wno-dangling-pointer -Wvla -Wno-pointer-sign -Wcast-function-type -Wno-unterminated-string-initialization -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-type-limits -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -g -Wall -Wstrict-prototypes -DVMW_USING_KBUILD -DVMMON -DVMCORE -I/home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include -I/home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86 -I/home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./common -I/home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./linux  -fsanitize=bounds-strict -fsanitize=shift    -DMODULE  -DKBUILD_BASENAME='"cpuid"' -DKBUILD_MODNAME='"vmmon"' -D__KBUILD_MODNAME=kmod_vmmon -c -o common/cpuid.o common/cpuid.c  

source_common/cpuid.o := common/cpuid.c

deps_common/cpuid.o := \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_INTEGER_WRAP) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler_attributes.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler-gcc.h \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/driver-config.h \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/SMP) \
    $(wildcard include/config/MODVERSIONS) \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/includeCheck.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/compat_version.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/generated/uapi/linux/version.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/compat_autoconf.h \
    $(wildcard include/config/SUSE_VERSION) \
    $(wildcard include/config/SUSE_PATCHLEVEL) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated/uapi/asm/types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/int-ll64.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/int-ll64.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi/asm/bitsperlong.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitsperlong.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/bitsperlong.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/posix_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/stddef.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/stddef.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/posix_types.h \
    $(wildcard include/config/X86_32) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi/asm/posix_types_64.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/posix_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/args.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/array_size.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
    $(wildcard include/config/CFI_CLANG) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated/asm/rwonce.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/rwonce.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/cleanup.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/err.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated/uapi/asm/errno.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/errno.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/errno-base.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/errno.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/errno.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/overflow.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/limits.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/limits.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/vdso/limits.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/const.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/vdso/const.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/const.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/stdarg.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/string.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/string.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/string_64.h \
    $(wildcard include/config/KMSAN) \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/jump_label.h \
    $(wildcard include/config/JUMP_LABEL) \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/jump_label.h \
    $(wildcard include/config/HAVE_JUMP_LABEL_HACK) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/asm.h \
    $(wildcard include/config/KPROBES) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/stringify.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/extable_fixup_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/nops.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/fortify-string.h \
    $(wildcard include/config/CC_HAS_KASAN_MEMINTRINSIC_PREFIX) \
    $(wildcard include/config/GENERIC_ENTRY) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/bitfield.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/build_bug.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi/asm/byteorder.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/byteorder/little_endian.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/byteorder/little_endian.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/swab.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/swab.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/uapi/asm/swab.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/byteorder/generic.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/objtool.h \
    $(wildcard include/config/FRAME_POINTER) \
    $(wildcard include/config/MITIGATION_UNRET_ENTRY) \
    $(wildcard include/config/MITIGATION_SRSO) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/objtool_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/once_lite.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kern_levels.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/export.h \
    $(wildcard include/config/GENDWARFKSYMS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/linkage.h \
    $(wildcard include/config/CALL_PADDING) \
    $(wildcard include/config/MITIGATION_RETHUNK) \
    $(wildcard include/config/MITIGATION_SLS) \
    $(wildcard include/config/FUNCTION_PADDING_BYTES) \
    $(wildcard include/config/UML) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/ibt.h \
    $(wildcard include/config/X86_KERNEL_IBT) \
    $(wildcard include/config/FINEIBT_BHI) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/ratelimit_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/bits.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/vdso/bits.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/bits.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/param.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/generated/uapi/asm/param.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/asm-generic/param.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/spinlock_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/qrwlock_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/dynamic_debug.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_assert.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_basic_types.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/FTRACE_MCOUNT_RECORD) \
    $(wildcard include/config/RHEL_DIFFERENCES) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/align.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/vdso/align.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/container_of.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/bitops.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/typecheck.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/kernel.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/uapi/linux/sysinfo.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/generic-non-atomic.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/barrier.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/alternative.h \
    $(wildcard include/config/CALL_THUNKS) \
    $(wildcard include/config/MITIGATION_ITS) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/barrier.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/bitops.h \
    $(wildcard include/config/X86_CMOV) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/rmwcc.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/sched.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/arch_hweight.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/cpufeatures.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/const_hweight.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/instrumented-atomic.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/instrumented.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kmsan-checks.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/instrumented-non-atomic.h \
    $(wildcard include/config/KCSAN_ASSUME_PLAIN_WRITES_ATOMIC) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/instrumented-lock.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/le.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/hex.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/kstrtox.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/math.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/div64.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/asm-generic/div64.h \
    $(wildcard include/config/CC_OPTIMIZE_FOR_PERFORMANCE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/minmax.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/sprintf.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/instruction_pointer.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/include/linux/wordpart.h \
  common/hostif.h \
  common/vmx86.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86apic.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86msr.h \
  /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/arch/x86/include/asm/msr-index.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/community_source.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/modulecall.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/cpu_types.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_basic_defs.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86/cpu_types_arch.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/address_defs.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86segdescrs.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_pagetable.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/ptsc.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/rateconv.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_basic_asm.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_basic_asm_x86_common.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_basic_asm_x86_64.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_atomic.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/versioned_atomic.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_atomic_acqrel.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vm_atomic_relaxed.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vcpuid.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vcpuset.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/vcpuset_types.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/contextinfo.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86desc.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/mon_assert.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/uccost.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/uccostTable.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/iocontrols.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/overheadmem_types.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/pageLock_defs.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/sharedAreaType.h \
  common/apic.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/sharedAreaVmmon.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/statVarsVmmon.h \
  common/hostifMem.h \
  common/hostifGlobalLock.h \
  common/cpuid.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86cpuid.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86vendor.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86cpuid_asm.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86svm.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86vt.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86vt-vmcs-fields.h \
  /home/lamarujian/vmware-host-modules-workstation-17.6.0/vmmon-only/./include/x86vt-exit-reasons.h \

common/cpuid.o: $(deps_common/cpuid.o)

$(deps_common/cpuid.o):
