savedcmd_vmmon.o := ld -m elf_x86_64 -z noexecstack --no-warn-rwx-segments   -r -o vmmon.o @vmmon.mod  ; /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/tools/objtool/objtool --hacks=jump_label --hacks=noinstr --hacks=skylake --ibt --orc --retpoline --rethunk --sls --static-call --uaccess --prefix=16  --link  --module vmmon.o

vmmon.o: $(wildcard /usr/src/kernels/6.16.0-0.rc0.250527g914873bc7df9.3.fc43.x86_64/tools/objtool/objtool)
